sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History"
], function (BaseController, MessageBox, Utilities, History) {
	"use strict";
	

	return BaseController.extend("com.sap.build.standard.assessmentTool.controller.Home", {
	});
}, /* bExport= */ true);		